from faceyolo.models import *
from faceyolo.utils.datasets import *
from faceyolo.utils.utils import *
import numpy as np
import torch
import os

# 目标侦测
# 定义目标侦测类
# 步骤
# 1、init方法中 配置模型以及模型的参数
# 2、侦测图片目标 返回边界框 类别 概率
#    加载图片 opencv
#    对图片数据预处理
#    侦测
#    数据处理
#    类别下标--》具体类别名字
#    返回边界框 类别 概率
# 3、侦测图片目标 返回带有标记的图片和类别

# 获取当前路径
current_path= os.path.dirname(__file__)
class YOLOv4Detector:
    def __init__(self, 
                img_size=640,
                cfg_file="yolov4-tiny.cfg",
                weights="best_yolov4-tiny.pt",
                names="mydata.names"):
        #参数详细化
        self.img_size = img_size
        # 路径
        self.cfg_file = os.path.join(current_path,F"data/{cfg_file}")
        self.weights = os.path.join(current_path,F"data/{weights}")
        self.names = os.path.join(current_path,F"data/{names}")

        #配置模型
        self.model = Darknet(self.cfg_file, self.img_size)
        # 加载训练好的模型
        self.model.load_state_dict(torch.load(self.weights)['model'])
        self.CUDA = torch.cuda.is_available()
        if self.CUDA:
            self.model.cuda()
        # 不调用求导 权重更新的方法
        self.model.eval()

        #self.names 路径  ====》具体的类别的值 
        #load_classes utils.utils 
        self.names = load_classes(self.names)
    
    def detect(self,img0):
        """
            img0:opencv读取的原始图片
        """
        #图片的预处理  
        img = self.format_img(img0)
        # print("--------format----------------")
        # print(img.shape)
        if self.CUDA:
            img = img.cuda()

        # 计算侦测结果
        pred = self.model(img, augment=False)[0]
        pred = pred.cpu()

        # 进行最大化抑制
        pred = non_max_suppression(pred, 0.3, 0.8, merge=False, classes=None, agnostic=False)
        # print("------pred最大化抑制------")
        # 解析识别结果
        for det in pred:
            if det is not None and len(det):
                det[:, :4] = scale_coords(img.shape[2:], det[:, :4], img0.shape).round()

        return pred  # 总长6：目标位置与大小（0:3），目标概率(4)，目标类别[5]

    # 图片的预处理  
    def format_img(self, img0):
        # utils.datasets的方法letterbox
        img = letterbox(img0, new_shape=self.img_size)[0]
        img = img[:, :, ::-1].transpose(2, 0, 1)  # BGR to RGB
        img = np.ascontiguousarray(img)
        img = torch.from_numpy(img)
        img = img.float()
        img /= 255.0  # 0 - 255 to 0.0 - 1.0
        if img.ndimension() == 3: 
            img = img.unsqueeze(0)
        return img
          
    def load_image(self,img_file):
        img0 = cv2.imread(img_file)
        return img0    
    
    def get_name(self,idx):
        return self.names[idx]

    def detect_mark(self,img0):
        pred = self.detect(img0)[0]
        a = str(type(pred))
        if a != '<class \'NoneType\'>':
            pred = pred.detach().numpy()
            pred = pred.astype(np.int16)
            #print(type(pred))
            if pred is not None:
                # 标注 循环
                for result in pred:
                    #矩形框
                    x1,y1,x2,y2 = result[0:4]
                    #概率
                    prob = result[4]
                    #类别
                    clss = int(result[5])
                    #类别名
                    clss_name = self.get_name(clss)
                    # 在图片中绘制矩形
                    img0 = cv2.rectangle(img0, pt1=(x1, y1),pt2=(x2,y2), color=(0, 0, 255), thickness=2)
                return img0,clss_name
            else:
                return img0,None
        else:
            return img0,None

