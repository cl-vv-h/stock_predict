import torch
class Lstm(torch.nn.Module):
    def __init__(self, input_size, hidden_size, output_size=1,num_layers=4):
        super(Lstm, self).__init__()
        self.rnn = torch.nn.LSTM(input_size,hidden_size,num_layers)# 两层LSTM网络，
        self.reg = torch.nn.Linear(hidden_size,output_size)#把上一层总共hidden_size个的神经元的输出向量作为输入向量，然后回归到output_size维度的输出向量中

    def forward(self, x):
        x, _ = self.rnn(x)# 单个下划线表示不在意的变量，这里是LSTM网络输出的两个隐藏层状态
        s,b,h = x.shape
        x = x.view(s*b, h)
        x = self.reg(x)
        x = x.view(s,b,-1)#使用-1表示第三个维度自动根据原来的shape 和已经定了的s,b来确定
        return x

