from app.uis.trafficapp import TrafficApp
import sys
app = TrafficApp()
status = app.exec()
sys.exit(status)