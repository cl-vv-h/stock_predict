from PyQt5.QtWidgets import QApplication
from app.uis.trafficframe import TrafficFrame
from app.uis.loginframe import LoginFrame
from app.uis.detailframe import detailFrame
class TrafficApp(QApplication):
    def __init__(self):
        super(TrafficApp, self).__init__([])
        # 主界面 登录窗口
        self.detail_dlg=detailFrame()
        self.main_dlg = TrafficFrame(self.detail_dlg)    
        self.main_dlg._signal.connect(self.detail_dlg.getdata)    
        self.login_dlg = LoginFrame(self.main_dlg)
        self.login_dlg._signala.connect(self.main_dlg.getname)    
        # 登录窗口.show()
        self.main_dlg.show()
