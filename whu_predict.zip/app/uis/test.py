import pandas as pd


import pandas as pd
import numpy
import tushare


date=pd.date_range(start='20201209',periods=30,freq='B')
nums = [4, 1, 5, 2, 9, 6, 8, 7]
print(date)
sorted_nums = sorted(enumerate(nums), key=lambda x: x[1])
idx = [i[0] for i in sorted_nums]#下标
nums = [i[1] for i in sorted_nums]#排序从小到大

                
               
                