from PyQt5.QtCore import QThread,pyqtSignal
import cv2 as cv
import numpy as np
from faceyolo.detect import YOLOv4Detector
class LoginDev(QThread):
    #信号                                          验证成功  成功的用户名
    sign_video = pyqtSignal(bytes, int, int, int, bool,str)
    # 摄像头id
    def __init__(self, dev_id):
        super(LoginDev, self).__init__()
        self.dev_id = dev_id
        # 打开摄像头
        self.dev = cv.VideoCapture(0)

        #侦测对象
        self.detector = YOLOv4Detector()
        # 验证成功 
        self.users = []
        self.counter = 0

        self.is_valid = False
        self.username = ""
    def run(self):
        while True:
            reval,img=self.dev.read()
            if not reval:
                self.dev.open(self.dev_id)
                continue
            # img识别
            
            img,username=self.detector.detect_mark(img.copy())
            
            # 验证逻辑
            # 统计
            if username is not None:
                self.users.append(username)
                self.counter +=1
            if self.counter >=10:
                max_name = max(self.users,key=self.users.count)
                self.is_valid = True
                self.username = max_name
            # 传递视频流
            img = cv.cvtColor(img,cv.COLOR_BGR2RGB)
            data = img.tobytes()
            h,w,c = img.shape
            self.sign_video.emit(data,h,w,c,self.is_valid,self.username)
            QThread.usleep(100000)            
    def close(self):
        self.terminate()
        while self.isRunning():
            pass
        self.dev.release()        