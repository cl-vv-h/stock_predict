from PyQt5.QtWidgets import QDialog
from app.uis.loginui import Ui_Dialog
from app.uis.logindev import LoginDev
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QImage, QPixmap
from PyQt5 import QtCore
class LoginFrame(QDialog):
    _signala = QtCore.pyqtSignal(str)
    def __init__(self,parent=None):
        super(LoginFrame,self).__init__(parent)
        self.ui = Ui_Dialog()
        self.ui.setupUi(self)
        self.th = LoginDev(0)
        self.th.sign_video.connect(self.login)
        self.th.start()
    def login(self,data,h,w,c,is_valid,username):
        # cv---->QImage
        qimg = QImage(data, w, h, w*c, QImage.Format_RGB888)
        qpixmap = QPixmap.fromImage(qimg)
        self.ui.lbl_video.setPixmap(qpixmap)
        self.ui.lbl_video.setScaledContents(True)
        
        if is_valid:
           
            self._signala.emit(str(username))
            #当前窗口结束
            self.close()
            # 进入主窗口
            self.parentWidget().show()
            # 登录线程关闭
            self.th.close()
            


