from app.uis.detailui import Ui_Dialog
from PyQt5.Qt import Qt
import pandas as pd
import numpy
import tushare
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *
from app.uis.trafficframe import TrafficFrame
import predict
import tushare as ts
import numpy as np
import cv2


class detailFrame(QDialog):
    def __init__(self, *args):
        super(detailFrame, self).__init__()
        # 搭建界面   qt5-tools  designer
        # python按住路径 D:\Python36\Scripts
        # pyuic5:一个已经配置环境变量的指令
        #     切换到.ui文件路径下  命令行执行 pyuic5  -o 转换的py文件  被转换的ui文件

        self.ui = Ui_Dialog()
        self.ui.setupUi(self)
        
    def getdata(self, index):
        self.model=QStandardItemModel(30,2)
        self.model.setHorizontalHeaderLabels(['时间','涨跌幅'])
        b=numpy.loadtxt("app/uis/all_stocks_code.csv",str,delimiter=',')#b是股票编号和名称
        
        
        for row in range(30):
                
            df = tushare.get_hist_data(str(index),start='2019-12-09',end='2020-01-20')
            date=pd.date_range(start='20201209',periods=30,freq='B')
            zdf = df['p_change']
            zdf = numpy.array(zdf)
            sa=str(date[row])
            sb=str(zdf[row])
            for column in range(2):
            
                
                
                if column==0:
                        
                    
                    sa=sa.strip('00:00:00')
                    item = QStandardItem("%s"%(sa))
                    self.model.setItem(row, column, item)
                if column==1:
                        
                    
                    sb=sb.strip('[]')
                    sb=sb+"%"
                    item = QStandardItem("%s"%(sb))
                    self.model.setItem(row, column, item)
        
        self.ui.tableView.setModel(self.model)
        
        df2 = tushare.get_hist_data(str(index),start='2019-12-09',end='2020-01-20')
        pcg = df2['p_change']
        pcg = numpy.array(pcg,dtype=np.float32)
        pcg=pcg[0:30]
        #预测未来七天涨跌，存入result
        result = predict.predict_for_7days(pcg)
        #获取预测的七天后股价
        price = df['close']
        price = numpy.array(price,dtype=np.float32)
        price=price[0:30]
        pred_price = predict.price_cal(price,result)
        self.model2=QStandardItemModel(7,3)
        self.model2.setHorizontalHeaderLabels(['时间','预测涨跌幅','预测股价'])
        for row in range(7):
            df = tushare.get_hist_data(str(index),start='2019-12-09',end='2020-01-20')
            date=pd.date_range(start='20201209',periods=30,freq='B')
            sa=str(date[row])
            sb=str(result[row])
            sc=str(pred_price[row])
            for column in range(3):
                if column==0:
                        
                    
                    sa=sa.strip('00:00:00')
                    item = QStandardItem("%s"%(sa))
                    self.model2.setItem(row, column, item)
                if column==1:
                        
                    
                    
                    sb=sb.strip('[]')
                    sb=sb+"%"
                    item = QStandardItem("%s"%(sb))
                    self.model2.setItem(row, column, item)
                if column==2:
                        
                   
                    
                    sc=sc.strip('[]')
                    sc=sc+"%"
                    item = QStandardItem("%s"%(sc))
                    self.model2.setItem(row, column, item)
        newdate=pd.date_range(start='20201209',periods=37,freq='B')
        self.ui.tableView_2.setModel(self.model2)
        days = newdate
        test=pcg
        np.set_printoptions(precision=3, suppress=True)
        date=[]
        for i in range(len(days)):
            _str = str(days[i])
            t=_str.split()[0]
            t=t.replace('2020-','')
            t=t.replace('2021-','')
            date.append(t)
        predict.pig_output7(date,test)
        img_data = cv2.imread('predict_D7.png')
        self.img_data = img_data
        # cv图片转换成QT能显示的数据格式
        h,w,c = img_data.shape
        data = img_data.tobytes()
        imgae = QImage(data,w,h,w*c,QImage.Format_BGR888)
        pix = QPixmap.fromImage(imgae)
        width = self.ui.lbl_img.width()
        height = self.ui.lbl_img.height()
        scale_pix = pix.scaled(width,height,Qt.KeepAspectRatio)
        self.ui.lbl_img.setPixmap(scale_pix)
        