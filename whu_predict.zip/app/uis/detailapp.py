from PyQt5.QtWidgets import QApplication
from app.uis.detailframe import detailFrame
class detailapp(QApplication):
    def __init__(self,index):
        super(detailapp, self).__init__([])
        # 主界面 登录窗口
        
        self.detail_dlg=detailFrame()
        self.detail_dlg.getdata(index)
        self.detail_dlg.show()