import numpy
import tushare
a=numpy.loadtxt("app/uis/all_stocks_code.csv",str,delimiter=',')
print(a)
'''
for i in range(a.shape[0]):
    df = tushare.get_hist_data(a[i,0])
    print(df)
'''

df = tushare.get_hist_data(a[1342,0])
asd = df['volume']
asd = numpy.array(asd)
print(df['open'])
print(asd)