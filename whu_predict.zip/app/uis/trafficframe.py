import numpy as np
import tushare as ts
from app.uis.mm  import Ui_Dialog
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *
import sys
import numpy  
import tushare  
from PyQt5 import QtCore
import predict



class TrafficFrame(QDialog):
    _signal = QtCore.pyqtSignal(str)
    
    def __init__(self,parent=None):
        super(TrafficFrame, self).__init__(parent)
        self.ui = Ui_Dialog()   
        self.ui.setupUi(self)
        self.model=QStandardItemModel(40,9)
        self.model.setHorizontalHeaderLabels(['编号','股票名','开盘价','收盘价','最高价','最低价','成交量','价格变动',"涨跌幅"])
        
        self.ui.label_5.setText("2020-01-20")
        A=[]
        b=numpy.loadtxt("app/uis/all_stocks_code.csv",str,delimiter=',')#b是股票编号和名称
        
       
        for row in range(40):
            df = tushare.get_hist_data(b[row+34,0],start='2020-01-20',end='2020-01-20')
            for column in range(9):
            
                
                
                
                
                
                
                if column==0:
                    
                    
                    item = QStandardItem("%s"%(b[row+34,0]))
                    self.model.setItem(row, column, item)
                if column==1:
                   
                    item = QStandardItem("%s"%(b[row+34,1]))
                    self.model.setItem(row, column, item)
                if column==2:
                 
                 
                    
                
                    
                    kpj = df['open']
                    kpj = numpy.array(kpj)
                    s=str(kpj)

                    item = QStandardItem("%s"%(s.strip('[]')))
                    self.model.setItem(row, column, item)
                if column==3:
                    
                    
                    spj = df['close']
                    spj = numpy.array(spj)
                    s=str(spj)
                    item = QStandardItem("%s"%(s.strip('[]')))
                    self.model.setItem(row, column, item)
                if column==4:
                   
                   
                    zgj = df['high']
                    zgj = numpy.array(zgj)
                    s=str(zgj)
                    item=QStandardItem("%s"%(s.strip('[]')))
                    self.model.setItem(row, column, item)
                if column==5:
                    
                     
                     zdj = df['low']
                     zdj = numpy.array(zdj)
                     s=str(zdj)

                     item = QStandardItem("%s"%(s.strip('[]')))
                     self.model.setItem(row, column, item)
                if column==6:
                   
                   
                    cjl = df['volume']
                    cjl = numpy.array(cjl)
                    s=str(cjl)

                    item = QStandardItem("%s"%(s.strip('[]')))
                    self.model.setItem(row, column, item)
                if column==7:
                    
                    
                    jgbd = df['price_change']
                    jgbd = numpy.array(jgbd)
                    s=str(jgbd)

                    item = QStandardItem("%s"%(s.strip('[]')))
                    self.model.setItem(row, column, item)
                if column==8:
                    
                    
                    zdf = df['p_change']
                    zdf = numpy.array(zdf)
                    A.append(zdf)
                    s=str(zdf)
                    s=s.strip('[]')
                    s=s+"%"

                    item = QStandardItem("%s"%(s))
                    self.model.setItem(row, column, item)
        
        self.ui.tableView.setModel(self.model)
        self.ui.tableView.doubleClicked.connect(self.table_change)
        self.ui.pushButton.clicked.connect(self.record)
        sorted_nums = sorted(enumerate(A), key=lambda x: x[1])
        idx = [i[0] for i in sorted_nums]#下标
        nums = [i[1] for i in sorted_nums]#排序从小到大
        self.model3=QStandardItemModel(3,4)
        self.model3.setHorizontalHeaderLabels(['编号','股票名','涨跌幅','收盘价'])
        for row in range(3):
            df = tushare.get_hist_data(b[idx[39-row]+34,0],start='2020-01-20',end='2020-01-20')
            for column in range(4):
            
                if column==0:
                    
                    item = QStandardItem("%s"%(b[idx[39-row]+34,0]))
                    self.model3.setItem(row, column, item)
                if column==1:
                   
                    item = QStandardItem("%s"%(b[idx[39-row]+34,1]))
                    self.model3.setItem(row, column, item)
                if column==2:
                    s=nums[39-row]
                    s=str(s)
                    s=s.strip('[]')
                    s=s+"%"
                    item = QStandardItem("%s"%(s))
                    self.model3.setItem(row, column, item)
                if column==3:
                    zdf = df['close']
                    zdf = numpy.array(zdf)
                    A[row]=zdf
                    s=str(zdf)
                    s=s.strip('[]')
                    item = QStandardItem("%s"%(s))
                    self.model3.setItem(row, column, item)
               

        self.ui.tableView_3.setModel(self.model3)
        

    def table_change(self, index):
        row = index.row()
        match_id = self.model.data(self.model.index(row, 0))
        self._signal.emit(str(match_id))
        self.parentWidget().show()
    
    def getname(self,name):
        self.ui.textEdit_4.setText(name)
    def record(self):
        b=numpy.loadtxt("app/uis/all_stocks_code.csv",str,delimiter=',')#b是股票编号和名称
        number=[]
        buyprice=[]
        holdnumber=[]
        number.append(self.ui.textEdit.toPlainText()) 
        buyprice.append(self.ui.textEdit_2.toPlainText())
        holdnumber.append(self.ui.textEdit_3.toPlainText())
        A=[]
        for row in range(40):
            A.append(b[row+34,0])
        i=len(number)
        self.model2=QStandardItemModel(i,6)
        self.model2.setHorizontalHeaderLabels(['编号','股票名','持股数','迄今收益','预计七日收益','宜'])
        for column in range(6):
            for row in range(i):
                
                if column==0:
                    
                    item = QStandardItem("%s"%(number[row]))
                    self.model2.setItem(row, column, item)
                if column==1:
                    
                    index=A.index(number[row])
                    item = QStandardItem("%s"%(b[index+34,1]))
                    self.model2.setItem(row, column, item)
                if column==2:
                    item = QStandardItem("%s"%(holdnumber[row]))
                    self.model2.setItem(row, column, item)
                if column==3:
                    
                    df2 = tushare.get_hist_data(str(number[row]),start='2020-01-20',end='2020-01-20')
                    spj = df2['close']
                    spj = numpy.array(spj)
                    m=float(holdnumber[row])*(float(spj)-float(buyprice[row]))
                    item = QStandardItem("%.3f"%(m))
                    self.model2.setItem(row, column, item)
                if column==4:
                    df2 = tushare.get_hist_data(str(number[row]),start='2019-12-09',end='2020-01-20')
                    df = tushare.get_hist_data(str(number[row]),start='2020-01-20',end='2020-01-20')
                    spj = df['close']
                    spj = numpy.array(spj)
                    pcg = df2['p_change']
                    pcg = numpy.array(pcg,dtype=np.float32)
                    pcg=pcg[0:30]
                    result = predict.predict_for_7days(pcg)
                    price=spj
                    pred_price = predict.price_cal(price,result)
                    m=float(holdnumber[row])*(float(pred_price)-float(buyprice[row]))
                    item = QStandardItem("%.3f"%(m))
                    self.model2.setItem(row, column, item)
                if column==5:
                    df2 = tushare.get_hist_data(str(number[row]),start='2019-12-09',end='2020-01-20')
                    df = tushare.get_hist_data(str(number[row]),start='2020-01-20',end='2020-01-20')
                    spj = df['close']
                    spj = numpy.array(spj)
                    pcg = df2['p_change']
                    pcg = numpy.array(pcg,dtype=np.float32)
                    pcg=pcg[0:30]
                    result = predict.predict_for_7days(pcg)
                    price=spj
                    pred_price = predict.price_cal(price,result)
                    m=float(holdnumber[row])*(float(pred_price)-float(buyprice[row]))
                    if m<0:
                        item = QStandardItem("抛出")
                        self.model2.setItem(row, column, item)
                    if m>=0:
                        item = QStandardItem("入股")
                        self.model2.setItem(row, column, item)

        self.ui.tableView_2.setModel(self.model2)
        
        





      
        
    
        
        
        
        
    
   
        
        
        
         
        
        


