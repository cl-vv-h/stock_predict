import predict
import tushare as ts
import numpy as np

_data = np.loadtxt('./数据集/stock_2020-10-01-2020-12-08.csv',dtype=np.float32,delimiter=',')
_test = _data[22,0:37]
test = _test[0:30]

#获取一只股票最近30天的数据
df = ts.get_hist_data('600048')
pcg = df["p_change"]
pcg = np.array(pcg,dtype=np.float32)
pcg = pcg[0:30]
#print(pcg)

#预测未来七天涨跌，存入result
result = predict.predict_for_7days(pcg)
print(result)
result30 = predict.predict_for_30days(pcg)
print(result30)

#获取最近一天股价
price = df['close']
price = price[0]
print(price)

#获取预测的七天后股价

pred_price = predict.price_cal(price,result)
print(pred_price)

#预测七天后每一天股价
pred_prices = predict.price_cal_everyday(price,result)
print(pred_prices)

