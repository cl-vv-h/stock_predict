import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt 
import torch
import scipy.stats
from matplotlib.pyplot import MultipleLocator
import matplotlib.pyplot as plt
from lstm_model import Lstm

def zscore(data):
    for i in range(data.shape[0]):
        mean = data[i,].mean()
        std = data[i,].std()
        data[i,] = (data[i,]-mean)/std

def creat_dataset(dataset,look_back):
    data_x = []
    data_y = []
    for i in range(len(dataset)-look_back):
        data_x.append(dataset[i:i+look_back])
        data_y.append(dataset[i+look_back])
    return np.array(data_x, dtype=np.float32), np.array(data_y, dtype=np.float32) #转为ndarray数据

#_data是一个一维的长度为30的向量，也就是三十天的涨跌幅浮动,返回值result是预测的未来七天的涨跌幅
def predict_for_7days(_data):
    days = 30
    net = Lstm(days,22)
    net = net.cuda()
    criterion = torch.nn.MSELoss()
    optimizer = torch.optim.Adam(net.parameters(),lr=1e-2)

    net.load_state_dict(torch.load('./lstm模型/%processed30days584_predict_0.658398048442507.pkl')) 
    test = _data[0:30]

    for_pred = test
    for_pred = for_pred.reshape(-1,1,30)

    pre = torch.from_numpy(for_pred)
    pre = pre.cuda()

    pred_test = net(pre)
    pred_test = pred_test.cpu().view(-1).data.numpy()
    result = pred_test
    for i in range(0,6):
        test = np.hstack((test[1:30,],pred_test))

        for_pred = test[0:30]
        for_pred = for_pred.reshape(-1,1,30)

        pre = torch.from_numpy(for_pred)
        pre = pre.cuda()

        pred_test = net(pre)
        pred_test = pred_test.cpu().view(-1).data.numpy()
        result = np.hstack((result,pred_test))
    
    return result

#预测未来三十天涨跌幅
def predict_for_30days(_data):
    days = 30
    net = Lstm(days,22)
    net = net.cuda()
    criterion = torch.nn.MSELoss()
    optimizer = torch.optim.Adam(net.parameters(),lr=1e-2)

    net.load_state_dict(torch.load('./lstm模型/%processed30days584_predict_0.658398048442507.pkl')) 
    test = _data[0:30]

    for_pred = test
    for_pred = for_pred.reshape(-1,1,30)

    pre = torch.from_numpy(for_pred)
    pre = pre.cuda()

    pred_test = net(pre)
    pred_test = pred_test.cpu().view(-1).data.numpy()
    result = pred_test
    for i in range(0,29):
        test = np.hstack((test[1:30,],pred_test))

        for_pred = test[0:30]
        for_pred = for_pred.reshape(-1,1,30)

        pre = torch.from_numpy(for_pred)
        pre = pre.cuda()

        pred_test = net(pre)
        pred_test = pred_test.cpu().view(-1).data.numpy()
        result = np.hstack((result,pred_test))
    
    return result

#计算最终股价price
def price_cal(pre_price, result):
    price = pre_price
    for i in range(result.shape[0]):
        price = price * (1+result[i]/100)

    return price

#根据result计算未来每一天的股价
def price_cal_everyday(pre_price, result):
    prices = []
    price = pre_price
    for i in range(result.shape[0]):
        price = price * (1+result[i]/100)
        prices.append(price)

    prices = np.array(prices)

    return prices

#存储原始数据和预测七天的图像，其中date长度需要是37天
def pig_output7(date, _data):
    result = np.hstack((_data,predict_for_7days(_data)))
    zeros = np.zeros((7,))
    zeros = np.hstack((_data,zeros))
    for i in range(result.shape[0]):
        result[i] = round(result[i],2)
    
    plt.figure(figsize = (20,6))
    plt.plot(date, result, color='r')
    plt.plot(date,zeros,color='b')
    plt.xticks(fontproperties = 'Times New Roman', weight = 'bold', fontsize=10)
    plt.style.use('ggplot')
    font={'family':'serif',
    'style':'normal',
    'weight':'bold',
    'color':'black',
    'size':16
    }

    for a, b in zip(date, result):
        plt.text(a, b, b, ha='center', va='bottom', fontdict=font)
    plt.rcParams['font.sans-serif']=['simhei']
    plt.rcParams['axes.unicode_minus']=False
    #x_major_locator=MultipleLocator(40)
    #ax=plt.gca()
    #ax.xaxis.set_major_locator(x_major_locator)
    
    plt.savefig('predict_D7.png', dpi=1000, bbox_inches = 'tight')
    #plt.show()

#存储原始数据和预测三十天的图像，其中date长度需要是60天
def pig_output30(date, _data):
    result = np.hstack((_data,predict_for_30days(_data)))
    plt.plot(date, result)
    plt.savefig('predict_D30.png', dpi=1000, bbox_inches = 'tight')
    #plt.show()

'''
for i in range(data.shape[0]):
    for j in range(data.shape[1]):
        if data[i,j]>=0 :
            data[i,j]=1
        else:
            data[i,j]=0
'''


'''
#单只股票七天预测并绘图
days = 30
net = Lstm(days,22)
net = net.cuda()
criterion = torch.nn.MSELoss()
optimizer = torch.optim.Adam(net.parameters(),lr=1e-2)

net.load_state_dict(torch.load('./lstm模型/%processed30days584_predict_0.658398048442507.pkl')) 
#var_data = torch.from_numpy(x_test)#net在GPU上面，所以输入的测试集合也要转入到GPU上面

_data = np.loadtxt('./数据集/stock_2020-10-01-2020-12-08.csv',dtype=np.float32,delimiter=',')
_test = _data[22,0:37]
test = _test[0:30]

for_pred = test
for_pred = for_pred.reshape(-1,1,30)

pre = torch.from_numpy(for_pred)
pre = pre.cuda()

pred_test = net(pre)
pred_test = pred_test.cpu().view(-1).data.numpy()
print(pred_test)
result = pred_test
for i in range(0,6):
    test = np.hstack((test[1:30,],pred_test))

    for_pred = test[0:30]
    for_pred = for_pred.reshape(-1,1,30)

    pre = torch.from_numpy(for_pred)
    pre = pre.cuda()

    pred_test = net(pre)
    pred_test = pred_test.cpu().view(-1).data.numpy()
    result = np.hstack((result,pred_test))

result = np.hstack((_test[0:30],result))

days = []
for i in range(1,38):
    days.append(i)

plt.plot(days, _test, color='red', linewidth=2.0, linestyle='--')
plt.plot(days, result, color='blue',linewidth=3.0,linestyle='-.')
plt.show()
'''


'''
#预测准确率计算
var_data = x_test.cuda()
pred_test = net(var_data) # 测试集的预测结果
pred_test = pred_test.cpu().view(-1).data.numpy()#先转移到cpu上才能转换为numpy


true_data = np.array(y_test)
true_data = np.squeeze(true_data)

print(pred_test)
print(true_data)

t = abs(pred_test-true_data)<1
num = 0
for i in range(t.shape[0]):
    if t[i]:
        num = num + 1
print(num/t.shape[0])
'''